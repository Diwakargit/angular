from __future__ import print_function
print("before import")
import cx_Oracle
import os
# Yeah, you need this. 
with open('/tmp/HOSTALIASES', 'w') as f: f.write(f'{os.uname()[1]} localhost\n')

#os.environ['LD_LIBRARY_PATH']= '/home/ec2-user/Lambda-shit/v-env/lib/python3.6/site-packages/'
# Oracle away!
def lambda_handler(event, context):
    print("inside handler")
    return str(
        cx_Oracle.connect(
            'username',
            'password',
            cx_Oracle.makedsn(
                'rds.amazonaws.com', 1521, 'SOME_SID',
            )
        ).cursor().execute('SELECT 42 FROM DUAL').fetchone()
    )
#main("test","test")
